import torch
from torch import distributions
import matplotlib.pyplot as plt

dist = distributions.Normal(0,1)
proposal = distributions.Normal(0,1.3)
n=1000
samples = proposal.sample((n,))
ws = (dist.log_prob(samples)-proposal.log_prob(samples)).exp()
stats = ws*dist.log_prob(samples)
plt.hist(stats,50, density=True)
print(stats.std())

samples2 = dist.sample((n,))
stats2 = dist.log_prob(samples2)
plt.hist(stats2,50, density=True)
print(stats2.std())


x = torch.linspace(-3,3,1000)
y = dist.log_prob(x).exp()*dist.log_prob(x)
plt.plot(x,y, '.')

mix = distributions.Categorical(torch.ones(2,))
comp = distributions.Normal(torch.Tensor([-0.1, 0.1]), torch.Tensor([1.4, 1.4]))
gmm = distributions.MixtureSameFamily(mix, comp)
#plt.hist(gmm.sample_n(1000), density=True)

samples3 = gmm.sample((n,))
ws3 = (dist.log_prob(samples3)-gmm.log_prob(samples3)).exp()
stats3 = ws3*dist.log_prob(samples3)
plt.hist(stats3,50, density=True)
print(stats3.std())
