from bed.apnmc import APNMC, IS_Proposal
from bed.vnmc import VNMC
from simulator.pk import PK
import torch

import matplotlib.pyplot as plt
from torch import distributions
import matplotlib.pyplot as plt

dim = 2
init_design = 10*torch.rand(dim)

proposal = distributions.MultivariateNormal(loc=torch.Tensor([0.0,0.0,0.0]), covariance_matrix=1.2*torch.eye(3), validate_args=(False))
simulator = PK(init_design)
apnmc = APNMC(simulator, proposal)

n_trials = 100
est_prior = torch.zeros(n_trials)
est_proposal = torch.zeros(n_trials)
for i in range(n_trials):
    est_prior[i] = apnmc.nmc_reuse(100)
    est_proposal[i] = apnmc.nmc_reuse_proposal(100)

plt.hist(est_prior.detach().numpy())
plt.hist(est_proposal.detach().numpy())

print(torch.mean(est_prior), torch.mean(est_proposal))
print(torch.std(est_prior), torch.std(est_proposal))
print(apnmc.nmc_reuse(1000))
