from bed.apnmc import APNMC, IS_Proposal
from bed.apnmc_2 import APNMC_2
from bed.vnmc import VNMC
from simulator.pk import PK
import torch

import matplotlib.pyplot as plt
from torch import distributions
import matplotlib.pyplot as plt
from utils.plot import plot_hist_marginals

dim = 2
init_design = 20*torch.rand(dim)


proposal = distributions.MultivariateNormal(loc=torch.Tensor([0.0,-0.0,-0.0]), covariance_matrix=torch.Tensor([1.0,1.0,1.5])*torch.eye(3), validate_args=(False))
simulator = PK(init_design)
apnmc = APNMC(simulator)
apnmc2 = APNMC_2(simulator, proposal)

# plot the plotmatrix for parameters and observations
n_sims = 10000
parameters = simulator.prior.sample((n_sims,))
true_ys, noised_ys = simulator.forward(parameters)
samples = torch.cat((parameters, noised_ys.detach()), 1)
plot_hist_marginals(samples)

n_trials = 100
est_prior = torch.zeros(n_trials)
est_proposal = torch.zeros(n_trials)
for i in range(n_trials):
    est_prior[i] = apnmc.nmc_reuse(100)
    _, est_proposal[i] = apnmc2.nmc_reuse_proposal(100,100)

plt.figure()
plt.hist(est_prior.detach().numpy(),density=True,color="blue", alpha=0.5)
plt.hist(est_proposal.detach().numpy(),density=True,color="red", alpha=0.5)

print(torch.mean(est_prior), torch.mean(est_proposal))
print(torch.std(est_prior), torch.std(est_proposal))
print(apnmc.nmc_reuse(1000))
