from pyro.infer.mcmc import HMC, NUTS
from pyro.infer.mcmc.api import MCMC
from simulator.toy import Toy
from simulator.pk import PK
import torch
from utils.mcmcutils import NeuralPotentialFunctionForTrueModel
import matplotlib.pyplot as plt
from mcmc import Slice, SliceSampler, SVGDSampler
import utils
from utils.plot import plot_hist_marginals
import numpy as np
from bed.mcmc_gradient import *

torch.manual_seed(12)

dim = 5
init_design = 1.4+1*torch.rand(dim)
init_design = torch.linspace(0.5, 20, dim)
simulator = PK(init_design)
simulator.inner_noise_std = 0.1
simulator.noise_std = np.sqrt(0.1)
# =============================================================================
# parameters = torch.Tensor([[0.3]])
# ys = torch.Tensor([[0.6428, 0.5352]])
# =============================================================================


mcgrad = MCMC_Gradient(simulator, mcmc_param=1)
mcgrad.sampling_method = "adaptive_mh"

def plot_posterior():
    parameters = simulator.prior.sample((1,))
    _, ys = simulator.forward(parameters)
    n_in = 1000
    post_theta = []
    for i in range(1):
        #post_theta.append(mh([parameters, ys], simulator, n_in, 0.05))
        #post_theta.append(mala([parameters, ys], simulator, n_in, 0.005*noise_std))
        post_theta.append(adaptive_mh([parameters, ys], simulator, n_in, 1))
        
        if i % 10 == 0:
            print(simulator.acceptance_rate[-1])
    post_theta=torch.cat(post_theta)
    plot_hist_marginals(post_theta)
    return post_theta

post_theta = plot_posterior()