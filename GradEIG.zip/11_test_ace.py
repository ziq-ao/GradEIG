from utils.get_models import get_proposal
from utils.plot import plot_hist_marginals
from bed.apnmc import APNMC
from bed.vnmc import VNMC
from bed.ace import ACE
from simulator.pk import PK
import torch
from torch.nn.utils import clip_grad_norm_
import matplotlib.pyplot as plt


n_steps = 10000
lr = 1e-2
sim_budget = 5000*100
dim = 2
init_design = 0.1*torch.linspace(0.5, 20, dim)


# prepare for sim_model
simulator = PK(init_design)

# prepare for proposal
proposal = get_proposal("mdn", simulator.observation_dim, simulator.parameter_dim)
#clip_grad_norm_(proposal.parameters(), max_norm=0.0)


# learn
ace = ACE(simulator, is_proposal=proposal,sim_budget=500000)
ace.learn_design(lr=lr, n_out=10, n_in=10, n_steps=10000)

design_history = torch.cat(ace.design_history).view(-1, dim).numpy()
sim_count_history = ace.sim_count_history
for i in range(dim):
    plt.plot(sim_count_history, design_history[:,i], color="black")
    plt.plot(sim_count_history, design_history[:,i], color="black")
    
    

# apnmc
## method 1-1
simulator = PK(init_design)
apnmc = APNMC(simulator, sim_budget=sim_budget)

apnmc.learn_design(lr=lr, n_out=100, n_in=1, n_steps=n_steps, sampling_method="prior")
print(simulator.design)

design_history = torch.cat(apnmc.design_history).view(-1,dim).numpy()
sim_count_history = apnmc.sim_count_history
for i in range(dim):
    plt.plot(sim_count_history,design_history[:,i], color="blue")
    plt.plot(sim_count_history,design_history[:,i], color="blue")