from pyro.infer.mcmc import HMC, NUTS
from pyro.infer.mcmc.api import MCMC
from simulator.toy import Toy
from simulator.pk import PK
from simulator.regression import Regression
import torch
from utils.mcmcutils import NeuralPotentialFunctionForTrueModel
import matplotlib.pyplot as plt
from utils.plot import plot_hist_marginals

noise_std = 1/8
sim_model = Regression(torch.Tensor([-2,2.8,3]), noise_std=noise_std)
parameters = sim_model.prior.sample((1,))
_, ys = sim_model.forward(parameters)

# create the potential functon of target posterior distribution
potential_function = NeuralPotentialFunctionForTrueModel(
    sim_model=sim_model,
    prior=sim_model.prior,
    true_observation=ys,
)

kernel = HMC(potential_fn=potential_function,
             step_size=1e-3, 
             num_steps=10,
             #adapt_step_size=True
             )

# =============================================================================
# kernel = NUTS(potential_fn=potential_function,
#              #adapt_step_size=True,
#              step_size=1e-9,
#              )
# =============================================================================

# create sampler
thin = 1
num_samples = 1000
num_chains  = 1
warmup_steps = 0
initial_params = parameters
sampler = MCMC(
    kernel=kernel,
    num_samples=num_samples,
    warmup_steps=warmup_steps,
    initial_params={"": initial_params},
    num_chains=num_chains,
    mp_context="spawn",
)
sampler.run()
samples = next(iter(sampler.get_samples().values())).reshape(
    -1, sim_model.parameter_dim
)
samples1 = samples[::thin][:num_samples]
plot_hist_marginals(samples1)
print(sim_model.sim_count)

n_trials = int(num_samples/thin)
samples2 = []
for i in range(n_trials):
    thin = 1
    num_samples = 10
    num_chains  = 1
    warmup_steps = 0
    initial_params = parameters
    sampler = MCMC(
        kernel=kernel,
        num_samples=num_samples,
        warmup_steps=warmup_steps,
        initial_params={"": initial_params},
        num_chains=num_chains,
        mp_context="spawn",
    )
    sampler.run()
    samples = next(iter(sampler.get_samples().values())).reshape(
        -1, sim_model.parameter_dim
    )
    samples = samples[::thin][-1]
    samples2.append(samples)
samples2 = torch.cat(samples2).view(-1,3)
plot_hist_marginals(samples2)
    

# =============================================================================
# xs = torch.linspace(-0.2,0.4,100)
# potential_function({"":xs.view(-1)})
# =============================================================================
