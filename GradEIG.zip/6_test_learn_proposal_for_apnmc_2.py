from utils.get_models import get_proposal
from utils.plot import plot_hist_marginals
from bed.apnmc_2 import APNMC_2, IS_Proposal
from bed.vnmc import VNMC
from simulator.pk import PK
import torch
from torch.nn.utils import clip_grad_norm_
import matplotlib.pyplot as plt

# prepare for proposal
proposal = get_proposal("maf", None, 3)
clip_grad_norm_(proposal.parameters(), max_norm=10.0)
samples = proposal.sample(10000)
plot_hist_marginals(samples.detach(), lims=([[-3,3],[-3,3],[-3,3]]))

# prepare for sim_model
init_design = torch.Tensor([1,10])

simulator = PK(init_design)
apnmc2 = APNMC_2(simulator, proposal)

# plot the scatter of parameters vs observations
parameters = simulator.prior.sample((10000,))
true_ys, ys = simulator.forward(parameters)
plot_hist_marginals(torch.cat((parameters, ys.detach()),1))

# learn
apnmc2.learn_proposal(lr=1e-3, n_out=100, n_in=100, n_steps=1000)
samples = proposal.sample(10000)
plot_hist_marginals(samples.detach(), lims=([[-3,3],[-3,3],[-3,3]]))
