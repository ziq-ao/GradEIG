from pyro.infer.mcmc import HMC, NUTS
from pyro.infer.mcmc.api import MCMC
from simulator.toy import Toy
from simulator.pk import PK
import torch
from utils.mcmcutils import NeuralPotentialFunctionForTrueModel
import matplotlib.pyplot as plt
from mcmc import Slice, SliceSampler, SVGDSampler
import utils
import numpy as np

sim_model = Toy(init_design=torch.Tensor([0.2, 0.8]),)
# =============================================================================
# parameters = torch.Tensor([[0.3]])
# ys = torch.Tensor([[0.6428, 0.5352]])
# =============================================================================
parameters = sim_model.prior.sample((1,))
_, ys = sim_model.forward(parameters)

# create the potential functon of target posterior distribution
target_log_prob = (
    lambda parameters: sim_model.log_prob(ys, torch.Tensor(parameters))+
    sim_model.prior.log_prob(torch.Tensor(parameters))
    )

# create sampler
posterior_sampler = SliceSampler(
    utils.tensor2numpy(parameters).reshape(-1),
    lp_f=target_log_prob,
    thin=5,
    #max_width=0.1,
)
posterior_sampler.width=torch.Tensor([0.1])

# sample one sample each time
samples1 = []
for i in range(1000):
    posterior_sampler = SliceSampler(
        utils.tensor2numpy(parameters).reshape(-1),
        lp_f=target_log_prob,
        thin=3,
        #max_width=0.1,
    )
    posterior_sampler.width=torch.Tensor([0.1])
    samples1.append( posterior_sampler.gen(1))
samples1 = np.concatenate(samples1)
plt.figure()
plt.hist(samples1.reshape(-1),100,density=(True))
plt.axis([parameters-0.1, parameters+0.1, 0, None])
plt.hist(parameters.detach(),1000)
plt.axis([parameters-0.1, parameters+0.1, 0, None])
plt.figure()
plt.plot(samples1[:-1].reshape(-1), samples1[ 1:].reshape(-1), 'o')
print(sim_model.sim_count)

#sample many samples each time
posterior_sampler = SliceSampler(
    utils.tensor2numpy(parameters).reshape(-1),
    lp_f=target_log_prob,
    thin=10,
    #max_width=0.0,
)
posterior_sampler.width=torch.Tensor([0.1])
samples2 = posterior_sampler.gen(1000)
plt.figure()
plt.hist(samples2.reshape(-1),100, density=(True))
plt.axis([parameters-0.1, parameters+0.1, 0, None])
plt.hist(parameters.detach(),1000)
plt.axis([parameters-0.1, parameters+0.1, 0, None])
plt.figure()
plt.plot(samples2[:-1].reshape(-1), samples2[ 1:].reshape(-1), 'o')
print(sim_model.sim_count)
