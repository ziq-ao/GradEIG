from bed.apnmc import APNMC, IS_Proposal
from bed.vnmc import VNMC
from simulator.toy import Toy
import torch

import matplotlib.pyplot as plt

init_design = torch.rand(2)

## method 1-1
simulator = Toy(init_design, noise_std=0.01)
apnmc = APNMC(simulator)

apnmc.learn_design(lr=5e-3, n_out=100, n_in=1, n_steps=100, sampling_method="prior")
print(simulator.design)

design_history = torch.cat(apnmc.design_history).view(-1,2).numpy()
plt.plot(design_history[:,0], color="blue")
plt.plot(design_history[:,1], color="blue")

## method 1-2
simulator = Toy(init_design, noise_std=0.01)
apnmc = APNMC(simulator)

apnmc.learn_design(lr=5e-3, n_out=100, n_in=1, n_steps=100, sampling_method="prior_reuse_sims")
print(simulator.design)

design_history = torch.cat(apnmc.design_history).view(-1,2).numpy()
plt.plot(design_history[:,0], color="yellow")
plt.plot(design_history[:,1], color="yellow")

## method 2
simulator = Toy(init_design, noise_std=0.01)
vnmc = VNMC(simulator)

vnmc.learn_design(lr=5e-3, n_out=10, n_in=10, n_steps=100, sampling_method="pce")
print(simulator.design)

design_history = torch.cat(vnmc.design_history).view(-1,2).numpy()
plt.plot(design_history[:,0], color="red")
plt.plot(design_history[:,1], color="red")
