from simulator.toy2 import Toy
from utils.entropy import *
import torch


noise_std = 0.03216

init_design = torch.Tensor([0.4,1])
simulator = Toy(init_design, noise_std=noise_std)
parameters= simulator.prior.sample((1000000,))
_,ys = simulator.forward(parameters)
print(kl(ys.detach()))

init_design = torch.Tensor([1,0])
simulator = Toy(init_design, noise_std=noise_std)
parameters= simulator.prior.sample((1000000,))
_,ys = simulator.forward(parameters)
print(kl(ys.detach()))
