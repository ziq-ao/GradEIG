from pyro.infer.mcmc import HMC, NUTS
from pyro.infer.mcmc.api import MCMC
from simulator.toy import Toy
from simulator.pk import PK
import torch
from utils.mcmcutils import NeuralPotentialFunctionForTrueModel
import matplotlib.pyplot as plt
from mcmc import Slice, SliceSampler, SVGDSampler
import utils
from utils.plot import plot_hist_marginals
import numpy as np

dim = 5
init_design = 20*torch.rand(dim)
sim_model = PK(init_design)
# =============================================================================
# parameters = torch.Tensor([[0.3]])
# ys = torch.Tensor([[0.6428, 0.5352]])
# =============================================================================
parameters = sim_model.prior.sample((1,))
_, ys = sim_model.forward(parameters)

# create the potential functon of target posterior distribution
target_log_prob = (
    lambda parameters: sim_model.log_prob(ys, torch.Tensor(parameters))+
    sim_model.prior.log_prob(torch.Tensor(parameters))
    )

# create sampler
posterior_sampler = SliceSampler(
    utils.tensor2numpy(parameters).reshape(-1),
    lp_f=target_log_prob,
    thin=5,
    #max_width=0.1,
)
posterior_sampler.width=torch.Tensor([0.5,0.5,0.5])

# sample one sample each time
samples1 = []
for i in range(1000):
    posterior_sampler = SliceSampler(
        utils.tensor2numpy(parameters).reshape(-1),
        lp_f=target_log_prob,
        thin=3,
        #max_width=0.1,
    )
    posterior_sampler.width=torch.Tensor([0.5,0.5,0.5])
    samples1.append( posterior_sampler.gen(1))
samples1 = np.concatenate(samples1)
lims = torch.cat((parameters-3*samples1.std(0),parameters+3*samples1.std(0)),0)
lims = torch.transpose(lims, 0, 1)
lims = lims.tolist()
plt.figure()
plot_hist_marginals(samples1, lims = lims)
plt.figure()
plt.plot(samples1[:,:-1].reshape(-1), samples1[:, 1:].reshape(-1), 'o')
print(sim_model.sim_count)

#sample many samples each time
posterior_sampler = SliceSampler(
    utils.tensor2numpy(parameters).reshape(-1),
    lp_f=target_log_prob,
    thin=3,
    #max_width=0.0,
)
posterior_sampler.width=torch.Tensor([0.5,0.5,0.5])
samples2 = posterior_sampler.gen(1000)
plt.figure()
plot_hist_marginals(samples2, lims = lims)
plt.figure()
plt.plot(samples2[:,:-1].reshape(-1), samples2[:, 1:].reshape(-1), 'o')
print(sim_model.sim_count)
