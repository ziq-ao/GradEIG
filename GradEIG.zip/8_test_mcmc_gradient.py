from bed.apnmc import APNMC, IS_Proposal
from bed.vnmc import VNMC
from bed.mcmc_gradient import MCMC_Gradient
from simulator.pk import PK
import torch
import time
import multiprocessing as mp
import matplotlib.pyplot as plt

def main():
    dim = 2
    init_design = 5+0*torch.rand(dim)
    n_steps = 100
    lr = 1e-1
    
    ## method 1-1
    simulator = PK(init_design)
    mcmcgradient = MCMC_Gradient(simulator)
    
    # =============================================================================
    # grad = mcmcgradient.gradient_est([])
    # print(grad)
    # =============================================================================
    time_start = time.time()
    for i in range(10):
        grad = mcmcgradient.get_mcmc_gradient(10, 1,)
        print(grad)
    time_end = time.time()
    print(time_start-time_end)
    return grad
    
if __name__ == "__main__":
    grad = main()
