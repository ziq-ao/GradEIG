from bed.apnmc import APNMC, IS_Proposal
from bed.vnmc import VNMC
from simulator.pk import PK
import torch

import matplotlib.pyplot as plt

dim = 2
init_design = 0*torch.rand(dim)
n_steps = 100
lr = 1e-1

## method 1-1
simulator = PK(init_design)
apnmc = APNMC(simulator)

apnmc.learn_design(lr=lr, n_out=500, n_in=1, n_steps=n_steps, sampling_method="prior")
print(simulator.design)

design_history = torch.cat(apnmc.design_history).view(-1,dim).numpy()
for i in range(dim):
    plt.plot(design_history[:,i], color="blue")
    plt.plot(design_history[:,i], color="blue")

## method 1-2
simulator = PK(init_design)
apnmc = APNMC(simulator)

apnmc.learn_design(lr=lr, n_out=100, n_in=1, n_steps=n_steps, sampling_method="prior_reuse_sims")
print(simulator.design)

design_history = torch.cat(apnmc.design_history).view(-1,dim).numpy()
for i in range(dim):
    plt.plot(design_history[:,i], color="yellow")
    plt.plot(design_history[:,i], color="yellow")

## method 2
simulator = PK(init_design)
vnmc = VNMC(simulator)

vnmc.learn_design(lr=lr, n_out=10, n_in=10, n_steps=n_steps, sampling_method="pce")
print(simulator.design)

design_history = torch.cat(vnmc.design_history).view(-1,dim).numpy()
for i in range(dim):
    plt.plot(design_history[:,i], color="red")
    plt.plot(design_history[:,i], color="red")
