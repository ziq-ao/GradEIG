from bed.mcmc_gradient import *
from bed.apnmc import APNMC
from bed.vnmc import VNMC
from simulator.regression import Regression
import torch
from utils.plot import plot_hist_marginals

if __name__ == "__main__":
    torch.manual_seed(1)
    noise_std = 1/4
    simulator = Regression(torch.Tensor([-2,2.8,3]), noise_std=noise_std)
    apnmc = APNMC(simulator)
    vnmc = VNMC(simulator)
    mcgrad = MCMC_Gradient(simulator, mcmc_param=0.5*noise_std**2)
    mcgrad.sampling_method = "mh"
    
    #mcgrad = MCMC_Gradient(simulator, mcmc_param=0.005*noise_std)
    #mcgrad.sampling_method = "mala"
    
    mcgrad = MCMC_Gradient(simulator, mcmc_param=1)
    mcgrad.sampling_method = "adaptive_mh"
    
    print(simulator.EIG(), torch.autograd.grad(simulator.EIG(), simulator.design)[0])
    
    print("apnmc_results:")
    print(torch.autograd.grad(apnmc.nmc_reuse(1000), simulator.design)[0])
    
    print("vnmc_results:")
    print(torch.autograd.grad(vnmc.pce(1000,100), simulator.design)[0])
    
    print("mcmc_results:")
    print(mcgrad.get_mcmc_gradient(100, 1, use_multiprocessing=(False)))
    
    # slice sampling work poorly as the posterior is with 
    # strong dependencies among variables
    def plot_posterior():
        parameters = simulator.prior.sample((1,))
        _, ys = simulator.forward(parameters)
        n_in = 1
        post_theta = []
        for i in range(100):
            #post_theta.append(mh([parameters, ys], simulator, n_in, 0.5*noise_std**2))
            #post_theta.append(mala([parameters, ys], simulator, n_in, 0.005*noise_std))
            post_theta.append(adaptive_mh([parameters, ys], simulator, n_in, 1))
            
            if i % 10 == 0:
                print(simulator.acceptance_rate[-1])
        post_theta=torch.cat(post_theta)
        plot_hist_marginals(post_theta)
        return post_theta
    
    post_theta = plot_posterior()