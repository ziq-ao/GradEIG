from bed.apnmc import APNMC, IS_Proposal
from bed.vnmc import VNMC
from bed.mcmc_gradient import MCMC_Gradient
from simulator.toy import Toy
import torch
import numpy as np

import matplotlib.pyplot as plt

init_design = torch.rand(2)
noise_std = 0.01
sim_budget = 100*100
n_steps = 10000


## method 1
simulator = Toy(init_design, noise_std=noise_std)
apnmc = APNMC(simulator, sim_budget=sim_budget)

apnmc.learn_design(lr=5e-3, n_out=100, n_in=1, n_steps=n_steps, sampling_method="prior")
print(simulator.design)

design_history = torch.cat(apnmc.design_history).view(-1,2).numpy()
sim_count_history = apnmc.sim_count_history
plt.plot(sim_count_history, design_history[:,0], color="blue")
plt.plot(sim_count_history, design_history[:,1], color="blue")


## method 2
simulator = Toy(init_design, noise_std=noise_std)
vnmc = VNMC(simulator, sim_budget=sim_budget)

vnmc.learn_design(lr=5e-3, n_out=10, n_in=10, n_steps=n_steps, sampling_method="pce")
print(simulator.design)

design_history = torch.cat(vnmc.design_history).view(-1,2).numpy()
sim_count_history = vnmc.sim_count_history
plt.plot(sim_count_history, design_history[:,0], color="red")
plt.plot(sim_count_history, design_history[:,1], color="red")

## method mcmc-gradient
simulator = Toy(init_design, noise_std=noise_std)
mcmcgradient = MCMC_Gradient(simulator, mcmc_param=np.sqrt(noise_std), sim_budget=sim_budget)

mcmcgradient.learn_design(lr=5e-3, n_out=1, n_in=1, n_steps=n_steps,)
print(simulator.design)

design_history = torch.cat(mcmcgradient.design_history).view(-1,2).numpy()
sim_count_history = mcmcgradient.sim_count_history
plt.plot(sim_count_history, design_history[:,0], color="black")
plt.plot(sim_count_history, design_history[:,1], color="black")
